# 봉인된 등대 — Godot 적합성·플레이어블·캡처·Web pass

## 검증된 현재 프로덕션 (2026-10-23)

[프로덕션 별칭](https://sealed-lighthouse-trace-rpg.vercel.app)과
[생성 배포 주소](https://sealed-lighthouse-trace-n0aidojmn-akillness-projects.vercel.app)의
`dpl_5dv9w8DUeBJfc6cokE6ZzRfoto14`는 관측 상태 `READY`다.
[HTTP 근거](../../_workspace/current/qa/releases/2026-10-23-ontology-map/production-http-assets.json):
스테이징 게임·대시보드·PDF 18/18개 HTTP 200, 바이트 수·SHA-256 동일, 루트 307 → `/dashboard/`.
[프로덕션 브라우저 근거](../../_workspace/current/qa/releases/2026-10-23-ontology-map/browser/actual-game-acceptance.json):
stage-zero 거절, 렌즈, 설치/2단계, 최초 공개, 승인된 재표시, map 1440, map 390, 연속 진단의
8게이트 모두 PASS이며 console/page/request/HTTP 오류는 각각 0건이다. native 키보드·마우스와
DPR 2의 데스크톱 Chromium 세션 1개이며 390 px는 줄바꿈·키보드 검사이지 물리 모바일이 아니다.

[릴리스 영수증](../../_workspace/current/qa/releases/2026-10-23-ontology-map/final-verification.json)은
집중 검사 105개(동결 표본 62개 + 출판 회귀 43개), 시각 PASS(영수증 132개, SVG 10개,
이중 재생성 소스 22개), 각 10쪽 [EN](../../paper/latex/en/main.pdf) /
[KO](../../paper/latex/ko/main.pdf) PDF(651222 / 627058바이트)를 기록한다. [출판 소스 검사](../../tests/test_ontology_publication_sources.py)의
출처 정체성 음성 사례와 승인된 한·영 절 오라클은 런타임 권한이나 독립 인간 골드·효능 검증이
아니다. 전체 선택 소스 CI와 Git 전달은 Main의 별도 증명 대상이다. 프로덕션에서 추론하지 말고
최종 영수증과 현재 저장소 이력을 확인한다. [봉인 사례](../../research/development-cases/ontology-map-20261023-01/result.json)는
`n=1`, native CLI 6회, 반복 0회, 런타임 선택 `gpt-6.1-sol`, 제공자 정체성·리비전·비용 `null`
그대로다. Jev는 승인 권한 없는 부정적·미검증 `proposal_only` 조언이다. [소스 맵](../web/dashboard/ontology-map.json),
Godot writer 권한, 정식 R5 캡처와 과거 코호트는 변경하지 않는다. **G4/전체 G6는 `FIX`이며
효능·우월성·인간 편익은 입증하지 않는다.** 아래 R3/D-087은 과거 상태이며 현재 프로덕션만 대체한다.

## 선택된 엔진 근거

2026-10-23 갱신: [`current.json`](../../_workspace/current/engineering/tech-verification/current.json)이
선택한 ID는 `godot-4.7.1-20261023-publication-r5`이다.
[매니페스트](../../_workspace/current/engineering/tech-verification/evidence/godot-4.7.1-20261023-publication-r5/evidence-manifest.json)는
실제 Godot 실행 4종과 `2026-10-23 11:00:42` UTC의 macOS non-headless 스크립트 fixture-trace
재생 패널 3개를 기록한다. 참가자 gameplay나 라이브 모델 추론이 아니다.
과거 [R3 검증](../../_workspace/current/qa/releases/2026-10-23-signal-explainer/production-r3-final-verification.json)은
`dpl_BvpyBPiSouiyoyzN3wG9WQN16YNM`의 `PASS_FOR_APPROVED_BOUNDED_RELEASE`, Godot 정식
사례 7개, public-safe 검사 8개, 배포 자산 바이트 일치 9개를 기록한다. **G4와 전체 G6는
`FIX`이며 효능을 주장하지 않는다.** 이번 문서 갱신은 새 배포를 수행하지 않았다.

[논문 producer 매니페스트](../../paper/latex/generated/disclosure_producer_manifest.json)는
현재 `results-signal-explainer-20261023-r5` 결정론적 Python/Godot artifact의 출판 전용 materialization을 기록하며 새 모델 관측은 없다.
공개 인터뷰 파생본은 과거 비공개 원문과 바이트 동일하지 않다. 이 둘은 선택 렌더 및
[실제 브라우저 입력 gameplay 영수증](../../_workspace/current/qa/releases/2026-10-23-signal-explainer/receipt.json)과
구별한다. 해당 경로는 commit 3회와 hold 1회를 관측하고 미라의 승인 힌트에서 멈췄으며
조수위 표식 추리는 시도하지 않았다. 이후 공개 전용 관측이 추가되어도 소유자가
`current.json`을 갱신하지 않는 한 선택 렌더는 바뀌지 않는다.

과거 trace/receipt 수정 체크포인트에서 Main은 대상 8파일의 테스트 53개와 subtest 48개
통과를 보고했다. 현재 프로덕션과 별도 CI/Git 증명은 위 절을 따른다.

## 온톨로지 열람과 엔진 권한의 분리 (2026-10-23)

[대시보드](../web/dashboard/index.html)에서 `Tab`/`Enter` 또는 포인터로 **Engineering detail →
Ontology structure → evidence / 온톨로지 구조 → 근거**를 연다. 모바일 줄바꿈을 지원하는
읽기 전용 한·영 8역할 뷰는 선언과 관측 이벤트를 분리하며 누락·미보고는 통과가 아니다.
정규 참조는 [source JSON](../web/dashboard/ontology-map.json)에 유지하고 공개 UI에는 별칭을
쓰며 전체 상태는 노출하지 않는다. [봉인된 결과](../../research/development-cases/ontology-map-20261023-01/result.json)는
런타임이 `gpt-6.1-sol`을 선택한 Codex 개발 사례 1개, CLI 턴 6회, 독립 반복 0회, 검사 62개
통과, Web 빌드 성공과 실제 입력 거절·최초 공개·재표시, 1440/390 px 연속 진단 오류 0건을
기록한다. 제공자 정체성·리비전·비용은 `null`이다. [근거와 논문 링크](../design/paper-crosswalk.ko.md#51-온톨로지-구조근거-개발-사례)는
이를 고정 60-fixture, NPC88, 과거 `gpt-5.6-sol`과 구별되는 추가 공학 사례로 보존하며
인간 편익·재미·효능·생산성·온톨로지 우월성을 주장하지 않는다. Godot 소스·쓰기 권한·정식
R5 캡처는 그대로다. **G4/전체 G6는 `FIX`다.**

아래 과거 Cycle 3 기록은 fixture `4/4`, core `52/52`, 별도 D-073 확장 `4/4`, 아키타입
프로브 `5/5`를 보고한다. 보존 Cycle 2 v5 패킷과 배포 `dpl_AMVHgXcYKRgqz9UCyNUBfLhsfB3Y`는
당시 근거이며 현재 선택이나 배포가 아니다.

이 Godot 4.x 프로젝트는 논문에서 인용할 수 있도록 설계한 결정론적 마이크로 RPG
fixture다. 연구 런타임을 엔진에 내장하지 않고 엔진 로컬 저자 정책 미러를 실행한다. 지원
이벤트는 안정 브리지 envelope projection 검사를 통과하지만 라이브 Python 권한 왕복은
실행하지 않았다.

render-capture 진입점은 headless 적합성 runner와 의도적으로 분리된다. presentation 근거를
위해 동결된 정식 시점을 재생하고 실제 렌더 프레임을 기다린 뒤, 등록 PNG 3개와 source/render
메타데이터를 쓴다. action을 승인하거나 canonical state를 변경하지 않는다.

## 시나리오 경로

| 턴 | 플레이어/시스템 행동 | 하드 정책 결과 | 정규 상태 |
|---:|---|---|---|
| 0 | 꺼진 등대와 접근 가능한 등구점을 관찰 | 관찰 전용 | 불변 |
| 1 | 접근 가능한 신호 렌즈 획득 | 유효 commit | 인벤토리 변경, 퀘스트 1단계 |
| 2 | Captain Mira에게 미래의 배신 비밀과 잠긴 힌트 요청 | `FORBIDDEN_DISCLOSURE` + `STAGE_GATED_DISCLOSURE` | 안전 fallback, 불변 |
| 3 | 신호 렌즈 설치 | 유효 commit | 퀘스트 2단계, 힌트 승인 |
| 4 | 선택적 중복 ID 또는 timeout 주입 | 멱등 무시 또는 안전 fallback | 불변 |
| 5 | 승인된 조수 흔적 힌트 요청 | 유효 commit | 힌트 공개, 관계 기억 추가 |
| 6–8 | 저장, 불러오기, replay | 해시 비교 | 종료 해시 일치 필요 |

동결된 예상 종료 상태 해시는
`4b2310173dc059071fdc98e7705608d383dda81559706c3dd33bc96983108892`다.
이는 정규 JSON의 비밀키 없는 SHA-256 무결성 checksum이며 인증 수단이 아니다.
fixture는 이를 `python-independent-sealed-lighthouse-v1` oracle로 명시한다. Python 테스트는
GDScript와 독립적으로 같은 종료 상태 projection을 계산한다. 관측된 Godot fixture 실행 4종은 모두
그 해시와 일치했다.

## Godot 4.x에서 실행

저장소 프로젝트 루트에서 다음을 실행한다.

```bash
PROJECT_ROOT="$(pwd)"
GODOT_BIN="/absolute/path/to/godot4"
OUTPUT_DIR="/tmp/trace-rpg-godot-canonical"
"$GODOT_BIN" --headless --path "$PROJECT_ROOT/game-track/godot" --quit-after 120 -- \
  --fixture="$PROJECT_ROOT/data/fixtures/experimental-game-canonical.json" \
  --output="$OUTPUT_DIR"
```

결함 주입에는 fixture를 `experimental-game-duplicate-event.json`,
`experimental-game-timeout.json`, `experimental-game-corrupt-save.json` 중 하나로 교체한다.
정상 종료한 엔진 실행은 다음을 쓴다.

- `events.jsonl`: 모든 이벤트의 제안·근거·검증·수리·commit, 모델 revision, seed, 비용,
  지연시간, 변경 전후 상태 해시
- `save.json`: 버전 지정 저장 문서와 상태 해시
- `summary.json`: 엔진 버전, replay/저장 검사, 결함 수, 시간 표본

`OBSERVED_ENGINE_RUN` 표시는 실제 Godot 프로세스가 summary를 만들 때만 기록된다. 정적
테스트는 엔진 결과를 대신 만들지 않는다.

## 계약 검증

```bash
.venv/bin/python -m pytest -q tests/test_godot_experimental_game.py
ruff check tests/test_godot_experimental_game.py
```

Godot 4.x가 없으면 정적 계약 테스트가 통과하고 엔진 테스트는 명시적 사유와 함께
skip된다. Godot이 있으면 동일 테스트가 네 fixture를 모두 실행하고 이벤트·저장·요약을
JSON Schema로 검증한다.

현재 machine-bound 권위 근거 세트는
`../../_workspace/current/engineering/tech-verification/current.json`이 지정하며 현재
`evidence/godot-4.7.1-20261023-publication-r5/`로 해석된다. 정식/결함 주입 실행 4종은
각각 commit 3회를 수행하고 동결 종료/oracle 해시에 도달했으며, 손상 저장 probe는 live state
mutation 전에 거절됐다. 성능 budget은 모두 통과하지 않았다.
과거 Cycle 2 기록은 `40 tests, 44 subtests`, 이전 game-track gate는 `50 passed, 48 subtests`를
보고한다. 이전 선택 패킷의 5표본 헤드리스 frame p95(`116.667`, `100.000`, `98.760`,
`112.907 ms`)는 시작 transient를 포함한 과거 기록이며 새 선택 패킷이나 현재 interactive
frame 성능 측정값이 아니다.

## Non-headless capture 패킷

현재 capture 패킷은 선택된 불변 근거 세트
`godot-4.7.1-20261023-publication-r5`를 `SL-CAPTURE-001` 논문 label로 기록한다. R4(`godot-4.7.1-20261023-publication-r4`)와 이전 선택
`godot-4.7.1-20261023-signal-explainer-r1`, `godot-4.7.1-20261015t083849z-sealed-lighthouse-current-v3`과 더 오래된 패킷은 당시 근거로
보존한다. 선택된 primary 구조화 상태 패널은 다음과 같다.

| 패널 | source 시점 | 파일 |
|---|---|---|
| `sl-rc-001-arrival` | 도착 관찰 | `sl-rc-001-arrival.png` |
| `sl-rc-002-rejected-secret` | 조기 공개 거절과 fallback | `sl-rc-002-rejected-secret.png` |
| `sl-rc-003-authorized-hint` | 렌즈 설치 뒤 승인된 힌트 | `sl-rc-003-authorized-hint.png` |

승격에는 non-headless display driver, 렌더 프레임 동기화, 정확한 1280×720 크기,
non-blank/opacity 검사, 파일 byte/SHA-256, source fixture·run·event/state 시점·source hash 결속이
필요하다. primary 패킷에는 생성 콘셉트 asset이 없다.
현재 manifest는 capture pipeline, PNG decoder, capture schema, retained validator, `uv.lock`의
hash와 capture host Python/jsonschema tool version을 추가로 기록한다. verifier는 지원되는 다른
Python 버전에서도 실행할 수 있으며 기록된 capture 환경과 현재 source hash를 검증하되 동일
host라고 가장하지 않는다.

![도착 관찰](../../_workspace/current/engineering/tech-verification/evidence/godot-4.7.1-20261023-publication-r5/rendered-canonical-v1/sl-rc-001-arrival.png)

![공개 거절](../../_workspace/current/engineering/tech-verification/evidence/godot-4.7.1-20261023-publication-r5/rendered-canonical-v1/sl-rc-002-rejected-secret.png)

![승인 힌트](../../_workspace/current/engineering/tech-verification/evidence/godot-4.7.1-20261023-publication-r5/rendered-canonical-v1/sl-rc-003-authorized-hint.png)

## 3D 연출 슬라이스 (`scenes/main_3d.tscn`)

`scripts/game3d/`는 동일한 저자 정책 미러(`sealed_lighthouse_machine.gd`)를 유일한 정식 상태
저자[OBSERVED]로 사용하는 플레이 가능한 3D 연출 슬라이스다. 부두·램프 상점·해상 등대
실루엣·폭풍 날씨를 절차적으로 구성하고, SL-PRESENT-001 비트(P-B01~P-B06)와 B-011 긴장 곡선
`0.35→0.72→0.50`을 프레젠테이션 계층에서만 구동한다. 제안→커밋/보류 라우팅은 라이브 플레이와
스모크 스윕이 같은 코드 경로를 쓴다.

```bash
# 아래 모든 Godot 명령은 game-track/godot이 아닌 임시 import 복사본만 대상으로 한다.
STAGED_GODOT_PROJECT=/tmp/sl3d-disposable-project

# 플레이 (WASD, 마우스 시점, E, F5/F9, M 모션 감소, V 음향, T 안내)
godot --path "$STAGED_GODOT_PROJECT" res://scenes/main_3d.tscn

# Public-safe 헤드리스 스모크 (거절 불변·단계 게이트·손상 저장 거절 8종)
godot --headless --path "$STAGED_GODOT_PROJECT" res://scenes/main_3d.tscn -- --smoke --public-safe

# 임시 fixture + 프레젠테이션 매트릭스 (엔지니어링 전용)
python3 scripts/run_playable_evaluation.py --godot /path/to/Godot

# 큐레이션된 공개 플레이어 자산·출처·클립 계약
python3 scripts/validate_player_asset.py

# 개발용 검증 샷 (GUI host 전용, 이 sandbox에서는 불가, 승격 불가)
godot --path "$STAGED_GODOT_PROJECT" res://scenes/main_3d.tscn -- \
  --shot /tmp/sl3d-shot.png --shot-stage arrival --public-safe
```

스모크 스윕 8검사는 2026-08-30 Godot 4.7.1에서 다시 통과했고 종료 상태 해시는 동결 해시
`4b2310…8892`와 일치한다. 기존 프레젠테이션 검사는 활성화된 `BoxShape3D`가 보이는
렌즈 접근 덱과 일치하고 `GoldenPathLayout`의 앵커를 포함하며 부두와 겹치고 램프 상점 벽을
감싸는지도 확인한다. 이는 DEF-021의 공학 결함만 닫으며 사람의 길찾기 성공을 주장하지 않는다.
Godot을 사용할 수 있는 로컬 테스트는 disposable copy에서 이 스모크를 실행한다.
Web과 `--public-safe`는 `../assets/concepts/` 및
`../assets/concepts/pack-3d/`의 검토 대기 후보를 로드하지 않는다. 대신 별도 큐레이션 UI
lane과 추적 대상 `assets/player/higgsfield-player.glb`의 `Idle`/`Casual_Walk`을 절차 월드·VFX·
음향 위에 사용한다. 플레이어 외형과 클립 상태는 정식 상태나 저장 데이터에 들어가지 않는다.
검토 대기 콘셉트 후보의 공개 승격에는 계속 사람 권리·스타일 검토가 필요하다.

## Cycle 3 평가 매트릭스와 최신 작업 캡처

| `SL-PLAY-EVAL-001` 행 | 검사 | 결과 |
|---|---:|---|
| 정식 fixture | `10/10` | PASS |
| 중복 이벤트 fixture | `10/10` | PASS |
| timeout fixture | `10/10` | PASS |
| 손상 저장 fixture | `10/10` | PASS |
| 프레젠테이션 불변조건 (core) | `12/12` | PASS |
| **합계 (core, 논문 인용 ENG1)** | **`52/52`** | **PASS** |
| D-073 확장 불변조건 (증거판·추리·힌트 사다리·trace mirror) | `4/4` (전체 `56/56`) | PASS |
| 아키타입 밸런스 프로브 | `SL-BALANCE-PROBE-001` 5/5 | PASS |

fixture `4/4` 모두 정확한 종료 SHA-256
`4b2310173dc059071fdc98e7705608d383dda81559706c3dd33bc96983108892`에 도달했다.
[전체 매트릭스](docs/latest/evaluation-matrix.md), [JSON 매트릭스](docs/latest/evaluation-matrix.json),
[원시 프레젠테이션 평가](docs/latest/presentation-evaluation.json)를 확인할 수 있다.

| 도착 | 보류 |
|---|---|
| ![Cycle 3 public-safe 도착](docs/latest/arrival.png) | ![Cycle 3 public-safe 보류](docs/latest/refusal.png) |
| 승인 단서 | 항로 획득 결말 |
| ![Cycle 3 public-safe 승인 단서](docs/latest/authorized_hint.png) | ![Cycle 3 public-safe 결말](docs/latest/ending.png) |

네 1280×720 PNG는 이 샌드박스에서 Godot `--shot` 렌더가 불가능해 임시 Web stage와 브라우저로
생성한 최신 엔지니어링 작업 캡처다. 캡처 전용 query hook은 추적 source에 들어가지 않았다.
불변 v5 패킷을 대체하거나 수정하지 않는다.

과거 전체 경로 스크립트 gameplay(dev 전용 `main_3d.tscn -- --autoplay --public-safe`, `--write-movie`, 2026-09-19): **[H.264 MP4, 76.3초](docs/latest/trace-rpg-gameplay.mp4)** · **[GIF](docs/latest/golden-path.gif)**
(MP4 `1280×720`, 30 fps, 2,289 프레임, 10,990,889바이트, SHA-256
`c20c197e2b2568bda24d0c80f646fee2c80e15b5a4867b02f60e44dae56e551c`; GIF 560×315, 6 fps, 305 프레임 1.5배속, 6,469,565바이트, SHA-256
`e353f35370cd75822a4cd86889c2a8dcdd72941b3ec936f390c1da60a88bf5cf`). D-073 슬롯 조립 추리와 페이지형 영수증으로 끝나는
엔지니어링 시연이다.

## Public-safe Web 산출물 빌드

저장소 프로젝트 루트에서 실행한다.

```bash
./scripts/build_godot_web.sh
python3 -m http.server 4173 --directory game-track/web/public
```

빌더는 Godot 프로젝트를 임시 디렉터리로 복사하고 그 복사본에서만 `main_3d.tscn`을 선택한다.
단일 스레드·확장 비활성 Web preset을 사용하며 정식 `project.godot`은 변경하지 않는다. 근거
결속된 실제 프로젝트에는 Godot editor/import를 실행하지 않는다. 2026-08-30 무시 대상
2026-09-03 산출물은 런타임 파일 10개 / 50,754,386바이트이며 `index.pck`은 10,902,124바이트, SHA-256
`b92af65d854d921440cd8b748591ce13032de989f3697e6b6648c855b9688075`이다. 이 산출물은
과거 **[Vercel `dpl_AMVHgXcYKRgqz9UCyNUBfLhsfB3Y`](https://sealed-lighthouse-trace-rpg.vercel.app)**에
`scripts/deploy_vercel_dashboard.sh`로 배포됐다. 당시 사이트 루트는 `/dashboard/`(D-065 라이브 commit-gate
대시보드, 파일 4개 / 32,117바이트)로 리다이렉트되고, 게임은 `/public/`에서 서빙되며, 예전 `/index.html`
링크는 그쪽으로 리다이렉트된다. 런타임 파일 10개와 대시보드 파일 4개는 익명 요청에서 모두 `200`이며
스테이징 바이트와 일치했다. WASM은 `application/wasm`, 설정된 응답 헤더가 유지됐으며 `vercel.json`은
`404`를 반환했다. headless 프로덕션 검사는 대시보드를 열고 임베드된 게임을 시작해 헤더에서 초기 snapshot
hash `f488d9c4…812c`를 받았고, 1440×900 데스크톱에서 콘솔·페이지 오류 0건, 390×844에서 가로 넘침 없음을
확인했다(이전 배포 기록이며 `vercel-dashboard-mobile.png`는 과거 캡처를 유지한다). 포인터 잠금 진입은 자동화로는
여전히 **미검증**이다. 2026-08-17 headless 합성 클릭은 `pointerlockerror`를 냈고 Playwriter 클릭은 포인터
잠금 요청을 만들지 않았으며, HUD `시점 잠김`은 게임 자체 상태 표시라 사람 제스처 확인이 미해결 항목이다.
배포 절차: `scripts/deploy_vercel_dashboard.sh`(`--dry-run`은 스테이징 영수증만 출력).

**Cycle 3 주장 경계:** 저자 fixture와 프레젠테이션 불변조건 엔지니어링 적합성만 다룬다.
G4, 사용성, 몰입, 정서, 플레이어 효능, 모델 효능은 **UNASSESSED**다. G6는 프로덕션
save/reload, 현 배포 모바일 검증, 사람 포인터/음향 확인, warmed frame/input, 30분 soak,
rollback 근거가 없어 `FIX`다.

## Gameplay 대시보드 미리보기 (2026-10-02)

과거 2026-10-02 미리보기: 로컬 대시보드 `http://localhost:8788/dashboard/`는 게임을 주 화면으로 두고 엔진이 보고한 3단계 quest·플레이어/지점 지도·최근 행동·선택/고정 가능한 판정을 표시했다. 페이지는 게임 명령을 보내거나 정식 상태를 쓰지 못했다. `docs/latest/vercel-dashboard.png`는 렌즈 회수 뒤의 로컬 실제 gameplay 기록이다(stage 1/3, commit 1, hold 2). 그 날짜에는 독립 브라우저 gate가 대기 중이어서 프로덕션 배포가 차단됐으며, 이는 이후 R3 릴리스 상태가 아니다. Layout과 합성 fixture는 사용성·재미·효능·G4/G6를 입증하지 않는다.

![렌즈 회수 뒤의 로컬 실제 gameplay 대시보드: stage 1/3과 렌즈 설치 목표](docs/latest/vercel-dashboard.png)

## 온보딩 증거철과 엔진 밖 소프트 제안 채널 (2026-08-18)

- 영문 `[T]` 증거철 안내 3면(조작 -> 장부 문법 -> 실험 연결)이 첫 실행 시 자동으로 열리고
  이후 `[T]`로 재열람, `[Esc]`로 닫힌다. 사용자 큐레이션 Higgsfield 삽화는 `assets/ui/`로
  공개 빌드에 포함된다. 이를 지워도 이미지 슬롯만 숨고 문안과 절차 fallback은 완전하게 남는다.
  검토 대기 콘셉트 팩 바이트는 계속 제외한다.
- 첫 커밋·첫 보류에 일회성 설명 토스트가 붙어 "검증 통과만 상태를 바꾼다 / 보류는 상태를
  보존한다"를 즉시 전달한다. 렌즈를 들면 행동 패널에 아이콘 칩이 뜬다.
- LLM은 엔진 밖에만 있다. `scripts/soft_proposal_policy.py`가 프롬프트용 모델 가시 투영을
  만들고 회신에 봉인·단계 미달 식별자가 표면화됐는지 렉시컬 스크린으로 표시한다
  (`--projection`, `--proposal`). 스크린은 사전 필터이며 의미 오라클이 아니다.

## 고정 목표 NPC 운영 레인 (프로토콜 1.1)

이 절은 NPC 레인의 운영 경계다. 위의 Cycle 2/Cycle 3 내용은 별도의 역사적 Godot 프레젠테이션 근거로 유지한다. NPC 런타임은 열린 에이전트가 아니라 `sealed-lighthouse-v1`을 향하는 고정 목표 controller다.

- **권위와 loop.** 정식 상태의 유일한 writer는 Godot이다. Python은 typed intent를 해석하고, 여섯 필드 public observation에 대해 claim을 검증하며, 그 public projection만 대상으로 bounded BFS를 수행해 typed intent와 첫 번째 legal step만 낸다. hidden state를 읽거나 새롭고 전지적인 planning을 하지 않는다. 거절·모호성·world change 입력에서도 목표는 동일하며, 도달 불가능한 경로는 `NO_ROUTE`를 내고 physical step을 만들지 않는다.
- **하드 역할 gate.** `acquire_object`와 `install_lens`는 player의 명시적 요청이다. Captain Mira만 signal이 복구되고 tide lead가 승인되었으며 dialogue가 열린 뒤 알려진 승인 사실인 `reveal_hint` (`actor_id=captain_mira`, `fact_id=tide_marks_hint`)를 낼 수 있다. `clarify`와 `negotiate`는 정식 상태를 바꾸지 않는 dialogue operation이다. 기존 writer가 실행되기 전에 Godot은 issued action과 session, epoch, request, goal, policy, revision, state hash, deadline 결속을 검사하며, 검사와 write 사이에 `await`가 없다. `APPLIED` acquire/install/reveal은 revision을 올리고 state hash를 바꿔야 하며, `APPLIED` dialogue는 상태를 그대로 둔다. non-applied 결과는 상태를 바꾸지 않고, `STALE`은 채택하지 않는다.
- **프로토콜 identity.** 모든 envelope는 `npc-goal-recovery/1.1.0`을 사용하고 `configs/npc-goal-recovery.json`의 full-byte SHA-256 `d63f5679f360d3fd8d1a424422f5cae4a7096ba46441f746cdd97de56044e098`을 요구한다. disclosure 전용 `policy_hash`는 정수값 정규화 후의 policy digest `af0a1075294b11630d0828960c8eff6dbeccce5e6f2b414c2b5c1b0a1e405c36`이며 project hash가 아니다. 소스 `game-track/godot/project.godot` hash는 `2e7966bf2ac6b54bfaf2db84b3f446686436bd3a1f8efea592ffa82e91249edd`로 별도 기록한다.
- **전송과 cancellation.** loopback service는 `127.0.0.1:8768`에서 실행하고, canonical browser origin은 정확히 `http://127.0.0.1:8877`과 `http://localhost:8877`이다(`8767`은 canonical이 아니다). capability는 일시적인 `TRACE_RPG_NPC_CAPABILITY` 환경값과 `X-NPC-Capability` request header로만 공급하며 URL·storage·trace/log payload에는 넣지 않는다. live UI cancellation은 local HTTP/directive invalidation이다. epoch을 올리고 늦은 callback을 tombstone하지만 provider를 취소하지는 않는다. provider는 deadline까지 끝날 수 있고 bounded server trace/cache가 남을 수 있다. Core cancellation의 no-publication 보장은 unit/controller 테스트 경계이지 live route의 provider-cancel 보장이 아니다.
- **인증과 accounting.** P는 실제 공식 인증 Codex OAuth CLI adapter이며 rule fallback이 없다. R은 작성된 rule/grammar control이고, O는 같은 model family의 public-input-only auxiliary reference arm이며 independent oracle이나 semantic gold가 아니다. validated-v5 corpus는 총 28개 case(engineering 16개 + screening 12개)다. validated-v4와 비교해 바뀐 것은 `ENG-X01`과 `SCR-X01`뿐이다. 두 case 모두 `acquire_object`, `install_lens`, `open_dialogue` 뒤 `reveal_hint`를 명시적으로 요청하도록 고쳤고, 나머지 26개 case는 v4 semantics를 유지한다. validated v1-v4 packet은 보존된 diagnostic artifact이며 current-source proof가 아니다. Screening 배정은 P/R/O × 2(`arm당 24` observation, 총 `72`)로 유지하며, 모든 사전 배정 실패를 분모에 남긴다. episode accounting은 utterance epoch을 넘어 누적된다: intent deadline 30,000 ms, episode deadline 900,000 ms, intent call 8회, action attempt 32회, replan 16회, plan expansion 32회, in-flight 1개다. 배정은 engineering R 16개 observation과 screening 72개(P/R/O × 2, 각 24개)로 총 88개이며, arm별 합계는 R=40, P=24, O=24다. process quota는 실제 inference만 청구하고 cache hit나 invalid request는 청구하지 않는다. input/output token, cost, 반환된 model revision은 사용할 수 없으므로 `null`로 유지하며 `0`으로 쓰지 않는다.
- **snapshot과 replay.** Godot은 추적된 generated runtime mirror를 기계적으로 동일하게 로드한다. validated-v5 native snapshot은 위의 source provenance와 policy/config/project identity를 보존한다. Core snapshot replay는 epoch별 redacted recorded-intent replay이며 model call은 0회다. Native replay는 `--npc-experiment`로 정확한 immutable experiment input을 재실행하고 `engine_fixture_reexecution`으로 기록한다. 이를 `--npc-replay`라고 부르지 않는다.
live operator service는 일시적인 `TRACE_RPG_NPC_CAPABILITY` 환경값을 설정한 뒤 공식 OAuth와 rule fallback 없는 Codex arm을 명시해 실행한다:

```bash
codex login status
uv run python scripts/run_npc_service.py \
  --backend codex --model gpt-5.6-sol --host 127.0.0.1 --port 8768 \
  --allow-origin http://127.0.0.1:8877 \
  --allow-origin http://localhost:8877
```

### 검증된 packet과 별도 rerun

불변 canonical packet `research/academic-pipeline/npc-goal-recovery/verified-run-006/`에는 배정된 88행과 인증 CLI 실행 24회: 요청·반환된 모든 24개 model ID는 null이며, provider revision, provider seed, token 회계, cost도 모두 null이다. strict validation 통과. screening 각 arm의 실행 완료 20개와 stale-control ACK 거부에 따른 assigned failure 4개를 모두 유지하며, 관측된 goal 4/24를 recovery rate로 해석하지 않는다. O의 same-family 표기는 protocol source label이며 실제 모델 일치를 검증한 것이 아니다. 모델 미식별 `verified-run-001/`의 실패한 diagnostic, 역사적 batch `verified-run-002/`, `verified-run-003/`, 그리고 source-bound native 시연은 별도의 불변 근거다. 이들을 덮어쓰거나 합산하지 않는다. efficacy·superiority·generalization·human-benefit·independent-label을 주장하지 않는다.

```bash
uv run python scripts/run_npc_goal_experiment.py \
  --packet all --model gpt-5.6-sol \
  --engineering-fixtures data/fixtures/npc-goal-recovery/validated-v5/engineering.json \
  --screening-fixtures data/fixtures/npc-goal-recovery/validated-v5/screening.json \
  --output-dir _workspace/current/qa/npc-rerun-NEW-ID \
  --godot-project game-track/godot

uv run python scripts/validate_npc_goal_evidence.py \
  --packet all \
  --root "$PWD" \
  --packet-dir _workspace/current/qa/npc-rerun-NEW-ID
```

validator가 통과한 뒤에만 final packet 결과를 삽입하고 기존 bilingual paper fragment를 재생성한다. 논문의 기존 [NPC table/figure](../../paper/latex/figures/fig_npc_screening.svg)와 [기여·근거 matrix](../../research/academic-pipeline/npc-goal-recovery/npc-contribution-evidence-matrix.csv)가 evidence SSOT이며, 이 README는 결과를 복제하거나 recovery efficacy, superiority, generalization, player benefit, gold/accuracy ceiling, independent label을 주장하지 않는다.

## 증거 경계

보존 산출물은 Stage 6 M6의 설계 fixture 엔진 로컬 정책 미러 근거를 제공한다. 런타임 간 통합
논문 승격 전에는 라이브 Python 권한 왕복이 필요하다.
이 프로젝트는 모델 우월성, 플레이어 효용, 의미 oracle 완전성, 시각 품질, 상용 엔진
이식성을 측정하지 않는다. timeout과 중복 ID fixture는 설계된 결함 경로이며 모집단
오류율 추정치가 아니다.
중복 억제는 이 슬라이스의 단일 프로세스 메모리 안에서만 보장된다. 실제 adapter 승인
전에는 프로세스 간 영속 멱등성 저장소가 추가되어야 한다.
PNG는 저자 엔진 render/state 대응 근거만 추가한다. 시각 품질, 사용성, 몰입, input latency,
성능, 플레이어 효용, 의미 oracle, G4 또는 G6 근거를 추가하지 않는다.
