# 게임 개발 트랙 — 봉인된 등대

## 검증된 현재 프로덕션 (2026-10-23)

[프로덕션 별칭](https://sealed-lighthouse-trace-rpg.vercel.app)과
[생성 배포 주소](https://sealed-lighthouse-trace-n0aidojmn-akillness-projects.vercel.app)의 배포
`dpl_5dv9w8DUeBJfc6cokE6ZzRfoto14`는 관측 상태 `READY`다.
[HTTP 영수증](../_workspace/current/qa/releases/2026-10-23-ontology-map/production-http-assets.json)은
스테이징 게임·대시보드·PDF 자산 18개 모두 HTTP 200, 바이트 수·SHA-256 동일, 루트의
307 → `/dashboard/`를 기록한다. [프로덕션 실제 입력 영수증](../_workspace/current/qa/releases/2026-10-23-ontology-map/browser/actual-game-acceptance.json)은
stage-zero 거절, 렌즈 획득, 설치/2단계, 최초 공개, 승인된 재표시, map 1440, map 390,
연속 진단의 8게이트를 모두 통과했다. console/page/request/HTTP 오류는 각각 0건이다.
native 키보드·마우스 입력과 DPR 2를 사용한 데스크톱 Chromium 세션 1개이며, 390 px는
데스크톱 줄바꿈·키보드 검사이지 물리 모바일 기기의 gameplay가 아니다.

[릴리스 영수증](../_workspace/current/qa/releases/2026-10-23-ontology-map/final-verification.json)은
집중 검사 105개(동결 표본 검사 62개 + 출판 회귀 43개)와 시각 게이트 PASS(영수증 132개,
SVG 10개, 이중 재생성 소스 22개)를 기록한다. [출처 정체성 음성 사례와 승인된 한·영 절 오라클](../tests/test_ontology_publication_sources.py)은
출판 선언을 검사하며 런타임 권한, 독립 인간 골드 또는 효능 검증이 아니다.
현재 각 10쪽 [영문](../paper/latex/en/main.pdf) / [한국어](../paper/latex/ko/main.pdf) PDF는
651222 / 627058바이트다. 전체 선택 소스 CI와 Git 전달은 Main의 별도 증명 대상이므로
최종 영수증과 현재 저장소 이력을 확인한다. 검증된 프로덕션이 이 둘의 완료 증명은 아니다.
[봉인 사례](../research/development-cases/ontology-map-20261023-01/result.json)는 `n=1`, native CLI
6회, 독립 반복 0회, 런타임 선택 `gpt-6.1-sol`, 제공자 정체성·리비전·비용 `null` 그대로다.
Jev는 승인 권한 없는 부정적·미검증 `proposal_only` 조언이다. [소스 맵](web/dashboard/ontology-map.json),
정식 R5 엔진 캡처와 과거 코호트는 그대로다. **G4/전체 G6는 `FIX`이며 효능·우월성·인간
편익은 입증하지 않는다.** 아래 R3/D-087 기록은 과거 기록이며 현재 프로덕션 상태만 대체한다.

## 현재 근거 선택 (2026-10-23)

[`current.json`](../_workspace/current/engineering/tech-verification/current.json)이 선택한 ID는
`godot-4.7.1-20261023-publication-r5`이다.
[매니페스트](../_workspace/current/engineering/tech-verification/evidence/godot-4.7.1-20261023-publication-r5/evidence-manifest.json)는
실제 Godot 실행 4종과 `2026-10-23 11:00:42` UTC의 macOS non-headless 스크립트 fixture-trace
재생 패널 3개를 기록한다. 참가자 gameplay나 라이브 모델 추론이 아니며 패널은 아래에 있다.
과거 [R3 프로덕션 검증](../_workspace/current/qa/releases/2026-10-23-signal-explainer/production-r3-final-verification.json)은
배포 `dpl_BvpyBPiSouiyoyzN3wG9WQN16YNM`의 `PASS_FOR_APPROVED_BOUNDED_RELEASE`,
배포 자산 바이트 일치 9개, public-safe 검사 8개, Godot 정식 사례 7개를 기록한다.
이는 기존 영수증이며 이번 문서 갱신에서 새로 배포하거나 라이브 사이트를 재검사한 결과가 아니다.
**G4와 전체 G6는 `FIX`이며 효능이나 플레이어 편익 결과는 성립하지 않는다.**

네 근거 표면을 구분한다. 선택된 렌더는 저자 작성 render/state 대응이고,
[논문 producer 매니페스트](../paper/latex/generated/disclosure_producer_manifest.json)의 새 산출물은
현재 `results-signal-explainer-20261023-r5` 결정론적 Python/Godot artifact의 출판 전용 materialization이며 새 모델 관측은 없다.
공개 인터뷰 파생본은 과거 비공개 원문과 바이트 동일하지 않다.
[실제 브라우저 입력 gameplay 영수증](../_workspace/current/qa/releases/2026-10-23-signal-explainer/receipt.json)은
commit 3회와 hold 1회 뒤 미라의 승인 힌트에서 멈췄고 조수위 표식 추리는 시도하지 않았다.
이 근거들은 서로 대체하지 않는다. 이후 공개 전용 관측이 추가되어도 `current.json`을
변경하지 않는 한 선택 렌더를 대체하지 않는다.

과거 trace/receipt 수정 체크포인트에서 Main은 대상 8파일의 테스트 53개와 subtest 48개
통과를 보고했다. 이후 릴리스 근거는 위 현재 프로덕션 절에서 확인한다.

## 읽기 전용 온톨로지 근거 뷰 (2026-10-23)

[대시보드](web/dashboard/index.html)에서 키보드(`Tab` 다음 `Enter`) 또는 포인터로
**Engineering detail**을 열고 **Ontology structure → evidence / 온톨로지 구조 → 근거**를
확인한다. 모바일에서 줄바꿈되는 한·영 표는 World, Actor, Knowledge, Fact, Policy, Quest,
Action, Trace의 8역할 선언과 최신 관측 공개 이벤트를 분리한다. 정규 식별자와 근거 참조는
[source JSON](web/dashboard/ontology-map.json)에 유지하고 공개 UI에는 별칭을 쓴다.
누락·건너뜀·미보고 검사는 통과가 아니며 전체 정규 상태를 노출하거나 쓰기를 승인하지 않는다.

봉인된 [개발 결과](../research/development-cases/ontology-map-20261023-01/result.json)는 실제
Codex 런타임이 `gpt-6.1-sol`을 선택한 코딩 사례 1개, native CLI 턴 6회, 독립 반복 0회,
검사 62개 통과와 Godot Web 빌드 성공, 실제 입력 거절·최초 공개·승인된 재표시 및
1440/390 px의 연속 진단 오류 0건을 기록한다. 제공자 반환 모델 정체성·불변 리비전·비용은
미상(`null`)이다. 이는 별도 개발 공학 근거이며 60-fixture 확대, NPC trial, 인간 편익·재미·효능·
생산성·온톨로지 우월성 근거가 아니다. 과거 `gpt-5.6-sol` 관측과 NPC88은 변경하지 않는다.
공개 manifest, 실제 브라우저 PNG, 메커니즘 도식과 한·영 원고는
[논문/근거 연결표](design/paper-crosswalk.ko.md#51-온톨로지-구조근거-개발-사례)를 따른다.
Godot 소스·쓰기 권한, 정식 R5 캡처와 기존 60사례 코호트는 그대로이며,
**G4/전체 G6는 `FIX`다**. 현재 프로덕션과 별도 CI/Git 증명은 위 절을 따른다.

## 과거 릴리스 기록 (2026-09-06)

2026-09-06 업데이트: [게임·대시보드](https://sealed-lighthouse-trace-rpg.vercel.app/),
[영문 논문](https://sealed-lighthouse-trace-rpg.vercel.app/paper/en.pdf),
[한국어 논문](https://sealed-lighthouse-trace-rpg.vercel.app/paper/ko.pdf).
당시 인용 범위를 바로잡은 한·영 논문과 규칙 집계 오류를 수정한 대시보드를 함께 배포했다.
영수증의 배포 파일 일치 16개, 테스트 188개와 하위 검사 83개는 당시 관측이며 현재 런타임
인증이 아니다. 인간 사용성·모델 효과는 입증하지 않는다.
[과거 배포 검증 기록](../_workspace/current/qa/factcheck-release-2026-09-06.md)을 참고한다.

게임 트랙은 연구 코드를 엔진 내부에 직접 결합하지 않는다. 목표 아키텍처는 엔진이 안정 브리지
관찰을 보내고 연구 런타임이 권한 이벤트를 반환하는 구조다. 현재 Godot fixture는 엔진 로컬 저자
정책 미러를 실행한다. 지원 이벤트는 `schemas/game-bridge.schema.json`으로 projection되어 스키마
검증되지만 라이브 Python↔Godot transport는 아직 실행하지 않았다.

현재 구현은 이벤트/실험 스키마, 결정론적 검증, 상태 불변 fallback, 무결성 검사, operation/상태
해시 replay, frozen-response 어댑터에 Godot 4.x headless 실험 슬라이스와 별도 non-headless
render-capture pass를 추가한다. 저자 설계
Godot 경로는 항구 상태 로드, 접근 가능한 신호 렌즈 획득, 조기 금지/단계 제한 공개의 상태 불변
거절, 렌즈 설치, 이후 허용되는 조수 흔적 힌트, 저장/불러오기, 재생, duplicate/timeout/손상 저장
주입을 다룬다. 프로세스 간 영속 멱등성과 라이브 모델 transport는 계획 상태다.

라이브 어댑터 승인 조건:

- 엔진의 canonical state 변경은 유효한 `commit` 이벤트를 통해서만 일어난다.
- 모든 이벤트는 `run_id`, `episode_id`, `step`, `schema_version`, `world_state_hash`를 가진다.
- 재시도와 네트워크 중복은 영속 `event_id` 멱등성으로 제거해야 한다.
- 시간 초과, 모델 장애, 높은 감정 불확실성에서는 결정론적 안전 정책으로 fallback해야 한다.
- 연구 트랙은 실제 엔진 없이 mock bridge로 실행할 수 있고, 게임 트랙은 모델 없이 recorded trace를 재생할 수 있다.

선택 엔진은 Godot 4.x headless-first다. 엔진 선택 자체는 논문 기여가 아니며 프로토콜 호환성과 재현 가능한 상태 동일성이 기준이다.

시작 경로:

- [`design/gdd.ko.md`](design/gdd.ko.md) — 정식 실험 GDD
- [`design/paper-crosswalk.ko.md`](design/paper-crosswalk.ko.md) — RQ1--RQ5 및 Stage 6 연결표
- [`godot/README.ko.md`](godot/README.ko.md) — headless 실행과 근거 경계
- [`assets/README.md`](assets/README.md) — 권리 검토 전 생성 후보의 공개 안전 제외 매니페스트
- [`../_workspace/current/production/task-manifest.md`](../_workspace/current/production/task-manifest.md) — 현재 스튜디오 사이클

1차 계획 실험은 구조화 상태/텍스트를 사용한다. 생성 이미지는 제외되며 별도 동결 2차
VLM/UI 트랙에만 들어갈 수 있다. 설계나 headless 슬라이스는 참가자·모델 효능 결과를 만들지
않는다.

## Cycle 3 public-safe 플레이어블과 평가

현재 플레이어블 `godot/scenes/main_3d.tscn`은 3인칭 부두 탐색, 읽기 쉬운 상호작용 포커스,
반응형 장부 UI, 모션 감소, 풀링된 절차 VFX, 사용자 제스처 뒤 활성화되는 로컬 생성 음향을
추가한다. 2026-08-21 연출·게임필 패스로 전체를 심화했다: 긴장 곡선이 이끄는 날씨 아크(안개
색 보정, 바람에 기울어지는 비, 파도 요동, 보류 정점으로 어두워지는 하늘), 앞바다 원거리
번개와 지연된 절차 천둥, 부표·등불·물안개의 미세 움직임, 어두운 탑을 응시하는 느린 FOV
인트로, 항구 측 신호등 빔이 썰물 수로를 향해 쓸고 가는 결말 연출(앞바다 등대는 계속 어둡다),
가속·감속과 보폭 동기 시야 반동이 있는 민첩한 이동, 강화된 포커스·확정 어포던스, 커밋마다
고조되는 피드백, 바람·물결 앰비언스 위 7종 절차 음향 스팅어. 세계를 바꾸는 모든 의도는 계속
저자 설계 제안·검증 라우터를 거친다. 플레이어는 항구 측 신호를 복구하고 썰물 항로를 얻으며
앞바다 등대는 봉인된 채로 남는다.

같은 날 2차 패스는 논문의 트랜잭션을 디제시스로 만들었다: 제안은 3단계 판정 의식(호박색
검사 링 → 황동 섬광 기록 또는 슬레이트 봉인선 보류 → 정착)으로 심사되고, 항구 장부는
관료적·시적 목소리로 번호 붙은 항목을 기록하며 도장 아이콘을 찍는다. 미라는 3박자 서사
(폭풍의 밤, 절제된 희망, 조용한 에필로그)를 얻었고, 안내 2페이지는 제안·검증·보류·기록을
제안/검증/거부/커밋 루프에 그대로 대응시키며, 엔드 카드는 조수 항로 인장 아래 에피소드
영수증(기록·보류·상태 해시)을 싣는다. 큐레이션된 D-036 세계 텍스처(젖은 판자, 산화 황동,
돛 캔버스)와 도장/인장 아이콘은 전체 출처 기록과 검증된 절차 폴백과 함께 배포된다.

![스크립트 골든패스 경로(76초, 1.5배속): 인트로, 게이트를 명시한 보류, 렌즈 회수, 신호 복구, 조석 단서, 사건 종결 영수증](godot/docs/latest/golden-path.gif)

**[과거 전체 경로 스크립트 gameplay 영상(Godot Movie Maker `--autoplay --public-safe`, 2026-09-19, H.264 MP4, 76.3초)](godot/docs/latest/trace-rpg-gameplay.mp4)**은
D-073 로컬 빌드의 시작 게이트와 1페이지 필드 가이드, 게이트·규칙·의미를 명시한 보류, 렌즈 회수,
신호 복구, 승인된 조석 단서, 조수위 표식에서의 슬롯 조립 추리, 페이지형 사건 종결 영수증을
담는다(`1280×720`, 30 fps, 2,289 프레임, 10,990,889바이트; SHA-256
`c20c197e2b2568bda24d0c80f646fee2c80e15b5a4867b02f60e44dae56e551c`; commit 3, hold 1, 종단 SHA-256 `4b231017…108892`). 사용성·몰입·성능 근거가
아닌 엔지니어링 시연이다.

*이전 배포 `dpl_EbgGYuzM2E6gUuFcKFk26RHFpCWW`에서 캡처한 과거 32초 엔지니어링 기록
(시작 게이트 → 인트로 → 안내 → 부두)이다. 추적 플레이어와 현재 영문 산출물보다 오래됐다.
작업 아티팩트일 뿐 사용성·몰입·성능 근거가 아니다.*

| `SL-PLAY-EVAL-001` 행 | 검사 | 결과 |
|---|---:|---|
| 정식 fixture | `10/10` | PASS |
| 중복 이벤트 fixture | `10/10` | PASS |
| timeout fixture | `10/10` | PASS |
| 손상 저장 fixture | `10/10` | PASS |
| 프레젠테이션 불변조건 (core) | `12/12` | PASS |
| **합계 (core, 논문 인용 ENG1)** | **`52/52`** | **PASS** |
| D-073 확장 불변조건 (증거판·추리·힌트 사다리·trace mirror) | `4/4` (전체 `56/56`) | PASS |
| 아키타입 밸런스 프로브 | `SL-BALANCE-PROBE-001` 5/5 | PASS |

저자 fixture `4/4` 모두 정확한 종료 상태 SHA-256
`4b2310173dc059071fdc98e7705608d383dda81559706c3dd33bc96983108892`에 도달했다. 전체 표와
기계 판독 기록은 [`godot/docs/latest/evaluation-matrix.md`](godot/docs/latest/evaluation-matrix.md),
[`evaluation-matrix.json`](godot/docs/latest/evaluation-matrix.json)에 있다.

아키타입 밸런스 프로브(스크립트 실행 적합성, 사람 대상 아님):
[`balance-archetypes.md`](godot/docs/latest/balance-archetypes.md) ·
[JSON](godot/docs/latest/balance-archetypes.json)

![아키타입 밸런스 프로브 차트](godot/docs/latest/balance-archetypes.svg)

| 도착 | 보류 |
|---|---|
| ![Cycle 3 public-safe 도착](godot/docs/latest/arrival.png) | ![Cycle 3 public-safe 보류](godot/docs/latest/refusal.png) |
| 승인 단서 | 항로 획득 결말 |
| ![Cycle 3 public-safe 승인 단서](godot/docs/latest/authorized_hint.png) | ![Cycle 3 public-safe 결말](godot/docs/latest/ending.png) |

네 파일은 최신 1280×720 엔지니어링 작업 캡처이며 불변 Cycle 2 패킷이 아니다. Web과
`--public-safe`는 `assets/concepts/` 아래 검토 대기 후보를 계속 제외한다. 공개 빌드는 별도
큐레이션·출처 기록이 붙은 Higgsfield UI lane과 `godot/assets/player/higgsfield-player.glb`의
`Idle`/`Casual_Walk`을 함께 싣는다(9,677,324바이트, 15,463 triangle, 24 joint). UI PNG를
지워도 절차 표면은 플레이 가능하다. 플레이어 외형과 클립 상태는 프레젠테이션 전용이며 정식
상태나 저장 데이터에 들어가지 않는다.

**주장 경계:** 저자 fixture와 프레젠테이션 불변조건 적합성만 다룬다. G4, 사용성, 몰입,
정서, 플레이어 효능, 모델 효능은 **UNASSESSED**다. 프로덕션 데스크톱 재검증은 통과했다.
G6는 프로덕션 save/reload, 현 배포 모바일 검증, 사람 포인터/음향 확인, warmed frame/input,
30분 soak, rollback 근거가 생길 때까지 `FIX`다.

프로젝트 루트에서 실행한다.

```bash
./scripts/build_godot_web.sh
python3 -m http.server 4173 --directory game-track/web/public
```

과거 영문 UI + 추적 플레이어 배포 기록(2026-09-03): `/public/`, 런타임 파일 10개 /
50,754,386바이트, PCK 10,902,124바이트, SHA-256
`b92af65d854d921440cd8b748591ce13032de989f3697e6b6648c855b9688075`. 4파일 / 32,117바이트
commit-gate 대시보드는 사이트 루트에서 `/dashboard/`로 서빙된다.
과거 배포 상태: **[Vercel `dpl_AMVHgXcYKRgqz9UCyNUBfLhsfB3Y` READY](https://sealed-lighthouse-trace-rpg.vercel.app)**는 당시 기록이며 선택된 R3 배포가 아니다.
런타임과 대시보드 파일은 익명 요청에서 성공 응답을 주고 스테이징 바이트와 일치했다.
리다이렉트·MIME·보안 헤더·동일 출처 임베드 프레임 메시지 가드를 확인했다. 데스크톱과
390×844 대시보드 검사는 콘솔·페이지 오류 0건, 가로 넘침 0건이었다. 이전 2026-08-21 프로덕션 배포 `dpl_EbgGYuzM2E6gUuFcKFk26RHFpCWW`는
의식+텍스처 빌드를 서빙했다:
파일 11개, `index.pck` 5,970,516바이트, SHA-256
`b9706912530248c271979d1146537ab20ea4fff124e812c6195c7caf8d1c56eb`; 서빙된 html/pck/wasm을
다시 받아 로컬 산출물과 바이트 동일함을 확인했다. 별칭 대상 headless 브라우저 스모크로 AI
공개 표기가 붙은 키 아트 시작 게이트, 인트로 시네마틱, 안내 폴리오, 도장이 찍히는 디제시스
장부 목소리, 목표 흐름을 1280×720에서 확인했고 예상 밖 콘솔·페이지 오류는 0건이었다
(같은 날 앞선 배포 `dpl_J9STdbrWdiXyZakGuUWR7aD8jip9`에서 390×844도 동일하게 확인).
사람 제스처 포인터 잠금 확인은 미해결 항목으로 남는다(2026-08-17에도 headless 클릭은
`pointerlockerror`, 실제 Chrome 자동화는 포인터 잠금 요청 자체를 만들지 않았다).
빌드·과거 브라우저 스모크 상세: [Godot Web 안내](godot/README.ko.md#public-safe-web-산출물-빌드).

## 엔진 render-capture 근거

Cycle 2는 정식 저자 fixture를 별도 non-headless Godot pass로 렌더링한 1280×720 primary-track
패널 3개를 `SL-CAPTURE-001`로 등록한다.

| 패널 | 시점 | 파일 | 주장 한계 |
|---|---|---|---|
| `sl-rc-001-arrival` | 도착 관찰 | `sl-rc-001-arrival.png` | 저자 scene/state 대응 |
| `sl-rc-002-rejected-secret` | 공개 거절 | `sl-rc-002-rejected-secret.png` | 거절/fallback presentation 대응 |
| `sl-rc-003-authorized-hint` | 렌즈 설치 뒤 승인된 힌트 | `sl-rc-003-authorized-hint.png` | 승인 공개 presentation 대응 |

`SL-CAPTURE-001`은 엔진 manifest 필드가 아닌 논문 연결표 bundle label이며 manifest는 위
`sl-rc-*` capture ID 3개를 사용한다. 선택 불변 근거 세트 ID는
`godot-4.7.1-20261023-publication-r5`이며 `current.json`이 선택한다. R4(`godot-4.7.1-20261023-publication-r4`)와 이전
`godot-4.7.1-20261023-signal-explainer-r1`, `godot-4.7.1-20261015t083849z-sealed-lighthouse-current-v3`과 더 오래된 불변 패킷은
당시 근거로 보존한다. 선택 manifest는 capture pipeline, PNG decoder, schema, retained
validator, dependency lock, capture host tool version을 결속한다. 이 패널은 생성 콘셉트
아트가 아니라 구조화 상태/텍스트와 프로그램 방식 엔진 그래픽만 사용한다. 라이브 Python 권한,
모델·시각 효능, 사용성, 몰입, 인간연구 결과, G4 또는 G6를 입증하지 않는다.

![SL-CAPTURE-001 도착 관찰](../_workspace/current/engineering/tech-verification/evidence/godot-4.7.1-20261023-publication-r5/rendered-canonical-v1/sl-rc-001-arrival.png)

![SL-CAPTURE-001 공개 거절](../_workspace/current/engineering/tech-verification/evidence/godot-4.7.1-20261023-publication-r5/rendered-canonical-v1/sl-rc-002-rejected-secret.png)

![SL-CAPTURE-001 승인 힌트](../_workspace/current/engineering/tech-verification/evidence/godot-4.7.1-20261023-publication-r5/rendered-canonical-v1/sl-rc-003-authorized-hint.png)

오프라인 재현 안내: [`recorded-experiment.ko.md`](recorded-experiment.ko.md)
