# TRACE-RPG Supplemental Benchmark Package (Double-Anonymous Review)

This self-contained archive provides the reproducible TRACE-RPG benchmark artifacts (Phase 1–5),
pure-Python deterministic verifier core (`src/nesy_game/` + `src/nesy_game/multihop/`), Gebru et al.
datasheets (`data/DATASHEET.md`, `data/DATASHEET_v3.md`, `data/DATASHEET_v4.md`, `data/DATASHEET_v5.md`),
Croissant 1.0 v2 (12/12), archive-local Croissant 1.0 v3 (17/17), archive-local Croissant 1.0 v4 (22/22),
and archive-local Croissant 1.0 v5 (`data/croissant_trace_rpg_benchmark_v5.json`, 26/26 SHA-256 digests
with `data/...` contentUrls), `CHECKSUMS.sha256`, confound-free Phase-4 CLI + Godot 4.7.1 receipts,
and attested Anthropic Messages API Phase-5 receipts (`P15`–`P17`).

## Quick Verification (Zero External Dependencies, Python 3.10+)

```bash
python3 reproduce_benchmark.py
```

Running `reproduce_benchmark.py` performs six standalone checks without network calls or API keys:
1. **`CHECKSUMS.sha256` & Croissant 1.0 v2–v5 SHA-256 Verification:** Verifies all file checksums plus
   12/12 (v2), 17/17 (v3), 22/22 (v4), and 26/26 (v5) digests inside `data/`.
2. **Core `nesy_game.multihop` Closure & External Shielding Baselines:** Verifies semi-naive
   transitive Datalog closure, multi-hop leak detection, Safe-RL action masking, and NeMo-style
   Colang output rails inside `src/nesy_game/multihop/`.
3. **Deterministic Phase-1, Phase-2, & Phase-3 Re-execution:** Re-computes from scratch:
   - Phase-1 48-case multi-hop closure and 88-case calibrated EN/KO escape filter metrics;
   - Phase-2 120-case 5-world multi-hop closure, 30-episode 3-role 5-arm shielding, and 180-case escape;
   - Phase-3 480-case procedural Datalog scaling (`R in {8,16,32,64} x d in {1..5}`, Cochran's `Q = 1100.19`).
4. **Confound-Free Phase-4 Receipts (`P11`–`P14`):** Verifies schema, counts, and invariants across
   `P11` (30 3-family unguided MAS ep), `P12` (`84/90` + 27-fault candidate-inclusive `(a,E)` repair),
   `P13` (42 unguided Godot 4.7.1 replays), and `P14` (720 3-family 4-model EN/KO escape evaluations).
5. **Attested Direct-API Phase-5 Receipts (`P15`–`P17`):** Verifies `P15` (105 independent closed-loop
   5-turn episodes across 7 arms & 3 attested Claude 5.5 tiers, `15/15` replay checks per arm),
   `P16` (60 factorial `general_rule` vs. `ontology_multihop` episodes + 21 live API->Godot 4.7.1 replays
   incl. `6/6` `SealedLighthouseMachine` `EXACT_TERMINAL_HASH`), and `P17` (540 unified-prompt EN/KO escape calls).
6. **Human Packet Integrity:** Confirms `data/tr_human_eval_packet.json` preserves
   `AWAITING_HUMAN_RATERS`, `raters_completed == 0`, `krippendorff_alpha is None`, and zero synthetic labels.
