# TRACE-RPG Supplemental Benchmark Package (Double-Anonymous Review, v6)

This self-contained archive provides the reproducible TRACE-RPG benchmark artifacts (Phase 1–6),
pure-Python deterministic verifier core (`src/nesy_game/` + `src/nesy_game/multihop/`), Gebru et al.
datasheets (`data/DATASHEET.md`, `DATASHEET_v3.md`, `DATASHEET_v4.md`, `DATASHEET_v5.md`, `DATASHEET_v6.md`),
Croissant 1.0 v2 (`12/12`), v3 (`17/17`), v4 (`22/22`), v5 (`26/26`), and archive-local Croissant 1.0 v6
(`data/croissant_trace_rpg_benchmark_v6.json`, `30/30` SHA-256 digests with `data/...` contentUrls),
`CHECKSUMS.sha256`, executable anonymized Godot 4.7.1 benchmark scripts (`godot/`), confound-free
Phase-4 CLI + Godot 4.7.1 receipts, attested Anthropic Messages API Phase-5 receipts (`P15`–`P17`),
and Phase-6 industrial external KR solver (`P18`), authentic multi-world/large-scale Godot 4.7.1 (`P19`),
and 1,200-case 6-domain bilingual adversarial escape (`P20`) receipts.

## Quick Verification (Zero External Dependencies, Python 3.10+)

```bash
python3 reproduce_benchmark.py
```

Optional live Godot 4.7+ execution (requires `godot` on `PATH`):

```bash
python3 reproduce_benchmark.py --with-godot
```

Running `reproduce_benchmark.py` performs seven standalone checks without network calls or API keys:
1. **`CHECKSUMS.sha256` & Croissant 1.0 v2–v6 SHA-256 Verification:** Verifies all file checksums plus
   `12/12` (v2), `17/17` (v3), `22/22` (v4), `26/26` (v5), and `30/30` (v6) digests inside `data/`.
2. **Core `nesy_game.multihop` Closure & External Shielding Baselines:** Verifies semi-naive
   transitive Datalog closure, multi-hop leak detection, Safe-RL action masking, and NeMo-style
   Colang output rails inside `src/nesy_game/multihop/`.
3. **Deterministic Phase-1, Phase-2, & Phase-3 Re-execution:** Re-computes from scratch:
   - Phase-1 48-case multi-hop closure and 88-case calibrated EN/KO escape filter metrics;
   - Phase-2 120-case 5-world multi-hop closure, 30-episode 3-role 5-arm shielding, and 180-case escape;
   - Phase-3 480-case procedural Datalog scaling (`R in {8,16,32,64} x d in {1..5}`, Cochran's `Q = 1100.19`).
4. **Confound-Free Phase-4 Receipts (`P11`–`P14`):** Verifies schema, counts, and invariants across
   `P11`–`P14`.
5. **Attested Direct-API Phase-5 Receipts (`P15`–`P17`):** Verifies `P15` (`105` episodes), `P16` (`60`
   factorial + `21` Godot replays), and `P17` (`540` unified-prompt EN/KO escape calls).
6. **Phase-6 External Solvers, Large-Scale Godot, & 1,200-Case Escape (`P18`–`P20`):** Verifies `P18`
   (`120` 5-world + `1,080` `R<=256` Clingo/Z3/OWL 2 RL equivalence & cliffs), `P19` (`120/120` 5-world
   Godot 4.7.1 parity + `5,000`-tick 5-tier soak, `0` unsafe/leaks), `P20` (`1,200`-case 6-domain EN/KO
   escape benchmark, Jaccard `0.0630`, `Q = 871.39`), and optional `--with-godot` live re-execution of
   `godot/godot_phase6_multiworld_bench.gd`.
7. **Human Packet Integrity:** Confirms `data/tr_human_eval_packet.json` preserves
   `AWAITING_HUMAN_RATERS`, `raters_completed == 0`, `krippendorff_alpha is None`, and zero synthetic labels.
