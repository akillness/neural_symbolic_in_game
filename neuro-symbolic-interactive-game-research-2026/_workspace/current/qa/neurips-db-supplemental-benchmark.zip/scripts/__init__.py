"""Anonymized verifier scripts package."""
