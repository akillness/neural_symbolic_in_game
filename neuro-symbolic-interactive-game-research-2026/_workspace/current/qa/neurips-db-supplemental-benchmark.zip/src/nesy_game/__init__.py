"""TRACE-RPG research primitives."""

from .contracts import (
    ActionPolicy,
    CandidateAction,
    CommitOutcome,
    TraceAttempt,
    ValidationError,
    ValidationResult,
    WorldState,
)
from .experiment import (
    AdapterFailure,
    ExperimentCase,
    ExperimentRecord,
    ProposalAdapter,
    ProposalResponse,
    RecordedProposalAdapter,
    candidate_from_mapping,
    experiment_assignment_key,
    experiment_record_from_mapping,
    planned_experiment_assignment,
    run_experiment_case,
    summarize_experiment,
    verify_experiment_record,
    write_experiment_jsonl,
)
from .metrics import evaluate_trace
from .repair import (
    GUIDED_IRREPARABLE_CODES,
    GUIDED_REPAIRABLE_CODES,
    counterexample_guided_repair,
)
from .runtime import (
    execute_with_repair,
    parse_candidate_record,
    replay_trace_jsonl,
    replay_trace_record,
    to_jsonable,
    verify_trace_record,
    write_trace_jsonl,
)
from .validator import validate_candidate

__all__ = [
    "GUIDED_IRREPARABLE_CODES",
    "GUIDED_REPAIRABLE_CODES",
    "ActionPolicy",
    "AdapterFailure",
    "CandidateAction",
    "CommitOutcome",
    "ExperimentCase",
    "ExperimentRecord",
    "ProposalAdapter",
    "ProposalResponse",
    "RecordedProposalAdapter",
    "TraceAttempt",
    "ValidationError",
    "ValidationResult",
    "WorldState",
    "candidate_from_mapping",
    "counterexample_guided_repair",
    "evaluate_trace",
    "execute_with_repair",
    "experiment_assignment_key",
    "experiment_record_from_mapping",
    "parse_candidate_record",
    "planned_experiment_assignment",
    "replay_trace_jsonl",
    "replay_trace_record",
    "run_experiment_case",
    "summarize_experiment",
    "to_jsonable",
    "validate_candidate",
    "verify_experiment_record",
    "verify_trace_record",
    "write_experiment_jsonl",
    "write_trace_jsonl",
]
